from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

# --- 配置 ---
PRIVATE_KEY_PASSWORD = b"SVIEW_BY_ARTHUR_GU" 
# --- 配置结束 ---

def generate_keys():
    """
    生成 RSA 密钥对（私钥和公钥）并保存到文件。
    私钥使用密码加密保存。
    """
    print("--- 正在生成 RSA 密钥对 (2048位) ---")
    
    # 1. 生成私钥
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )

    # 2. 序列化私钥 (保存为加密的 PEM 文件)
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        # 使用 BestAvailableEncryption，确保私钥安全
        encryption_algorithm=serialization.BestAvailableEncryption(PRIVATE_KEY_PASSWORD)
    )

    private_file = "private_key.pem"
    with open(private_file, "wb") as f:
        f.write(private_pem)
    print(f"[✅ 成功] 私钥已生成并加密保存为: {private_file}")
    print(f"请妥善保管此文件及其密码，它是生成激活码的唯一凭证。")


    # 3. 获取公钥并序列化 (保存为文件，用于嵌入到您的客户端软件中进行验证)
    public_key = private_key.public_key()
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    public_file = "public_key.pem"
    with open(public_file, "wb") as f:
        f.write(public_pem)
    print(f"[✅ 成功] 公钥已生成并保存为: {public_file}")
    print(f"请将此公钥文件嵌入到需要激活的客户端软件中。")

if __name__ == '__main__':
    generate_keys()